Collatz.m will show you the Collatz sequence for the specified whole number, it will then print a graph that will display the results.

If you are unfamiliar with the 'Collatz Conjecture,' the wikipedia link goes into depth about what it is, and a numberphile video explains it pretty well too:

Wikipedia: https://en.wikipedia.org/wiki/Collatz_conjecture
Numberphile Video: https://www.youtube.com/watch?v=5mFpVDpKX70

(If it isn't obvious, please run the .m file in MATLAB (anything on or past version 2019a))